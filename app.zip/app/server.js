var express = require("express");
var mongoose = require("mongoose");
var config = require('./config/config');
var router = require('./router');

mongoose.connect(config.dbConnection)
.then(() => {

    console.log("Database Connected");
})
.catch(() => {

    console.log("Error in database connection")
})


var app = express();

// app.get("/", function(req, res) {

//     console.log("Hello Jaya")
//     res.send("Hey welcome to the app")
// })

app.use("/", router);

app.listen(config.port, () => {

    console.log("Server is running on" + config.port)
});
