var mongoose = require("mongoose");

var carModelSchema = mongoose.Schema({

    make: { type: String },
    models: { type: Array }
})

var carModels = module.exports = mongoose.model("carModels", carModelSchema)