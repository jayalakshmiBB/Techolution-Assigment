module.exports = {

    port: 3200,
    dbConnection: "mongodb://localhost:27017/assignment"
}