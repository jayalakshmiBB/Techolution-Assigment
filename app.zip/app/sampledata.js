
var sampledata = [

    {
        "make": "Ford",
        "models": [
            {
                "modelName": "Edge",
                "imgPath": "/images/Ford_Edge.jpg"
            }, 
            {
                "modelName": "Escape",
                "imgPath": "/images/Ford_Escape.jpg"
            }
          ]
    },
    {
        "make": "Acura",
        "models": [
            {
                "modelName": "ILX",
                "imgPath": "/images/Acura_ILX.jpg"
            }, 
            {
                "modelName": "MDX",
                "imgPath": "/images/Acura_MDX.jpg"
            }
          ]
    }


];

module.exports = sampledata;