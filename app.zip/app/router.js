var express = require("express");
var router = express.Router();
var data = require("./sampledata");
var carModels = require("./models/carsmodels");


router.get('/carsMake', (req, res) => {

    carModels.find({}, function (err, result) {

        if (err) {

            console.log(err)
        }
        else {

            // console.log("result", result)
            if (result.length == 0) {

                for (var i = 0; i < data.length; i++) {

                    let carModelData = new carModels(data[i]);
                    carModelData.save()
                        .then(res => {

                            // console.log("saved", res)
                        })
                        .catch(err => {

                            console.log("err", err)
                        })
                }

                carModels.find({}, function (err, docs) {

                    if(err) {

                        console.log(err)
                    }
                    else {

                        res.json(docs)
                    }
                })
            }

            else {
                res.json(result)
            }
        }
    })
})

module.exports = router;        