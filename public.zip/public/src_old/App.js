import React, { Component } from 'react';
import axios from "axios";


class App extends Component {

  componentWillMount() {

    axios.get("http://localhost:3500/data")
    .then(res => {

      console.log("response", res.data)
    })
  }
  render() {
    return (
      <div className="">


        
      </div>
    );
  }
}

export default App;
