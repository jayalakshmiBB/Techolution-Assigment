import React, { Component } from 'react';
import axios from "axios";
import { Select } from 'antd';
import 'antd/dist/antd.css';
const Option = Select.Option;

class App extends Component {

  constructor(props) {

    super(props);

    this.state = {

      carsMakeData: [],
      carsModelsData: [],
      content: "",
      imgContent: ""
    }

    this.handleChange = this.handleChange.bind(this);
    this.handleModelChange = this.handleModelChange.bind(this);

  }

  handleChange(data) {

    let makedata = this.state.carsMakeData;

    for (var i = 0; i < makedata.length; i++) {

      if (makedata[i].make == data) {

        this.setState({ carsModelsData: makedata[i].models })
      }
    }
  }

  handleModelChange(modelName) {

    this.setState({ content: modelName })
 
    for(var j=0; j<this.state.carsModelsData.length; j++) {

      if(this.state.carsModelsData[j].modelName == modelName) {

        this.setState({ imgContent: this.state.carsModelsData[j].imgPath})
      }
    }

  }

  componentWillMount() {

    axios.get("http://localhost:3200/carsMake")
      .then(res => {

        this.setState({ carsMakeData: res.data })
      })
  }

  render() {

    // console.log(this.state.carsModelsData)

    let divStyle = {};
    let divStyle2 = {};

    if (this.state.carsModelsData.length == 0) {

      divStyle = { disabled: true }
    }
    if (this.state.carsModelsData.length > 0) {

      divStyle = { disabled: false }
    }
    return (
      <div className="container" style = {{"padding": "25px" }}>

        <h2>Techolution Assignment</h2>

        
        <div className="col-md-7" style = {{"padding": "0px"}}>
        
         <div className="col-md-6" style = {{"padding": "0px"}}>
        <h4>Please select the make of a car</h4>
         <div>
          <Select
            placeholder="Select a car"
            style={{ "width": "200px" }}
            onChange={this.handleChange} >

            {this.state.carsMakeData.map(person => {

              return <Option value={person.make}>{person.make}</Option>
            })}

          </Select>
        </div>
         </div>
         
         <div className="col-md-6" >
         <h4>Please select the model of a car</h4>
         <div style = {divStyle}>
          <Select
            placeholder="Select the model of a car"
            style={{ "width": "200px" }}
            onChange={this.handleModelChange}
          >

            {this.state.carsModelsData.map(person => {

              {/* console.log("models", person.modelName) */}

              return <Option value={person.modelName}>{person.modelName}</Option>
            })}

          </Select>
        </div>
         </div>
        </div>
        <div className="col-md-12" style={{"marginTop":"75px","paddingLeft":"0px"}}>
        <p>Selected model of the car is {this.state.content}</p>
        </div>
      
        
        <br />
        <img src = {this.state.imgContent} />

      </div>
    );
  }
}

export default App;
